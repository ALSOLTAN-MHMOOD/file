* Owner
* Hannan AnSari

```
rm -rf FILE
git clone --depth=1 https://github.com/Hannan-404/FILE
cd FILE
python FILE.py
```

* ENJOY🥵🔥
